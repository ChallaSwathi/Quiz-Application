x = 123;
module.exports = x;