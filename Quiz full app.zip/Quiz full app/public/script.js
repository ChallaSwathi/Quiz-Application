let obj = {};
// let createbtn = document.getElementById("createbtn");
// createbtn.addEventListener("click",()=>{
//     obj = {};
// });

let name = document.getElementById("Quiz_name");
let submitbtn = document.getElementById("submitbtn");

submitbtn.addEventListener("click",()=>{
    console.log(name.value);
    fetch()
});